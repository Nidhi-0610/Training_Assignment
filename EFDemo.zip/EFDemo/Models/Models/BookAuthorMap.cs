﻿using Microsoft.EntityFrameworkCore;

namespace CodingWiki_Model.Models
{
    public class BookAuthorMap
    {
        public int Book_Id { get; set; }
        public int Author_Id { get; set; }

        public Book Book { get; set; }
        public Author Author { get; set; }

        public static void Configure(ModelBuilder modelBuilder)
        {
            var builder = modelBuilder.Entity<BookAuthorMap>();

            builder.HasKey(bam => new { bam.Book_Id, bam.Author_Id });

            builder.HasOne(bam => bam.Book)
                   .WithMany(b => b.BookAuthorMap)
                   .HasForeignKey(bam => bam.Book_Id);

            builder.HasOne(bam => bam.Author)
                   .WithMany(a => a.BookAuthorMap)
                   .HasForeignKey(bam => bam.Author_Id);
        }
    }
}
