﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace CodingWiki_Model.Models
{
    public class Author
    {
        public int Author_Id { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public DateTime BirthDate { get; set; }
        public string Location { get; set; }

        public List<BookAuthorMap> BookAuthorMap { get; set; } = new();

        public static void Configure(ModelBuilder modelBuilder)
        {
            var builder = modelBuilder.Entity<Author>();

            builder.HasKey(a => a.Author_Id);

            builder.Property(a => a.FirstName)
                   .IsRequired()
                   .HasMaxLength(50);

            builder.Property(a => a.LastName)
                   .IsRequired();

            builder.Property(a => a.Location)
                   .IsRequired(false);

            builder.HasMany(a => a.BookAuthorMap)
                   .WithOne(bam => bam.Author)
                   .HasForeignKey(bam => bam.Author_Id);
        }
    }
}
