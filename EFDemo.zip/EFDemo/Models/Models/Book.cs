﻿using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace CodingWiki_Model.Models
{
    public class Book
    {
        public int BookId { get; set; }
        public string Title { get; set; }
        public string ISBN { get; set; }
        public decimal Price { get; set; }

        public int Publisher_Id { get; set; }
        public Publisher Publisher { get; set; }

        public List<BookAuthorMap> BookAuthorMap { get; set; } = new();
        public BookDetail BookDetail { get; set; }

        public static void Configure(ModelBuilder modelBuilder)
        {
            var builder = modelBuilder.Entity<Book>();

            builder.HasKey(b => b.BookId);

            builder.Property(b => b.Title)
                   .IsRequired()
                   .HasMaxLength(200);

            builder.Property(b => b.ISBN)
                   .IsRequired();

            builder.Property(b => b.Price)
                   .HasPrecision(10,2);

            builder.HasMany(b => b.BookAuthorMap)
                   .WithOne(bam => bam.Book)
                   .HasForeignKey(bam => bam.Book_Id);

            builder.HasOne(b => b.BookDetail)
                   .WithOne(bd => bd.Book)
                   .HasForeignKey<BookDetail>(bd => bd.BookId);
        }
    }
}
