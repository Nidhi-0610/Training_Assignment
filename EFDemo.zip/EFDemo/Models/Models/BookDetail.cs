﻿using Microsoft.EntityFrameworkCore;

namespace CodingWiki_Model.Models
{
    public class BookDetail
    {
        public int BookDetailId { get; set; }
        public int BookId { get; set; }

        public int Pages { get; set; }
        public string Language { get; set; }
        public string Summary { get; set; }

        public Book Book { get; set; }

        public static void Configure(ModelBuilder modelBuilder)
        {
            var builder = modelBuilder.Entity<BookDetail>();

            builder.HasKey(bd => bd.BookDetailId);

            builder.Property(bd => bd.Pages)
                   .IsRequired();

            builder.Property(bd => bd.Language)
                   .IsRequired()
                   .HasMaxLength(50);

            builder.Property(bd => bd.Summary)
                   .IsRequired(false)
                   .HasMaxLength(1000);

            builder.HasOne(bd => bd.Book)
                   .WithOne()  
                   .HasForeignKey<BookDetail>(bd => bd.BookId)
                   .OnDelete(DeleteBehavior.Cascade);
        }
    }
}
