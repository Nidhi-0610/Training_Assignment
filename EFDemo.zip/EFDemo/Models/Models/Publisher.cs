﻿using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace CodingWiki_Model.Models
{
    public class Publisher
    {
        public int Publisher_Id { get; set; }
        public string Name { get; set; }
        public string Location { get; set; }

        public List<Book> Books { get; set; } = new();

        public static void Configure(ModelBuilder modelBuilder)
        {
            var builder = modelBuilder.Entity<Publisher>();

            builder.HasKey(p => p.Publisher_Id);

            builder.Property(p => p.Name)
                   .IsRequired();

            builder.Property(p => p.Location)
                   .IsRequired(false);

            builder.HasMany(p => p.Books)
                   .WithOne(b => b.Publisher)
                   .HasForeignKey(b => b.Publisher_Id);
        }
    }
}
